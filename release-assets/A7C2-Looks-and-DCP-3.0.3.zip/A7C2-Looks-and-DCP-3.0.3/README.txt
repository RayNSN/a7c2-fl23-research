A7C II Tools 3.0.0 - looks and DCP profiles

Profiles/      15 paired DCP + .a7look files (11 Fujifilm-style, 4 Ricoh GR III colour).
Default-Six/   The six looks installed by one-click setup (custom slots 1-6).
DCP/           All 18 DCPs (11 Fujifilm-style, 7 Ricoh GR III) and the FL2/FL3 DCPs.

.a7look files are written to the camera with A7C II Tools (Custom Creative Looks page).
DCPs are Lightroom/Camera Raw profiles for the Sony ILCE-7CM2; on Windows copy them to
%APPDATA%\Adobe\CameraRaw\CameraProfiles and restart Lightroom.

All files are used with the authors' permission and licensed under MIT (see LICENSE).
